/* Implement this class. */

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.Timer;
import java.util.concurrent.ConcurrentLinkedQueue;


public class MyHost extends Host {

    private Queue<Task> taskQueue = new ConcurrentLinkedQueue<>();

    private HashMap<Long,  LinkedList<Task>> addedTasks = new HashMap<Long,  LinkedList<Task>>();

    private LinkedList<Task> runningTasks = new LinkedList<>();
    private boolean isItrunning = true;
    private Task currentTask = null;

    private boolean taskAdded = false;

    int finishedTasks = 0;
    int totalTasks = 0;

    Instant startTime = Instant.now();
    Instant runTime;
    int oneSec = 0;



    @Override
    public void run() {
        while (runningTasks.size() != 0 || isItrunning) {
//            System.out.println(runningTasks);
            //
            Instant start = Instant.now();
            if (oneSec > 0 && !runningTasks.isEmpty()) {
                runningTasks.get(0).setLeft(runningTasks.get(0).getLeft() - 1000);
//                System.out.println("id: " + runningTasks.get(0).getId() + " - task.left: " + runningTasks.get(0).getLeft());

                if (runningTasks.get(0).getLeft() <= 0) {

                    //addedTasks.get(oneSec).remove(runningTasks.get(0));
                    finishedTasks++;
                    runningTasks.get(0).finish();
                    runningTasks.remove(0);
                }
            }

                for (int i = 0; i < 1; i++) {
                    try {
                        Thread.sleep(950);
                    } catch (InterruptedException e) {}
                    updateRunningTasks(oneSec);
                }

                while (Duration.between(start, Instant.now()).toMillis() <= 999);

                oneSec++;
        }

    }






            //
//            runTime = Instant.now();
//
//            int deltaTime = Duration.between(startTime, runTime).toMillisPart();
//            LinkedList <Task> taskList = addedTasks.get(deltaTime);
//
//            while(taskList.size() != 0) {
//
//            }


//            if (currentTask != null) {
//                long taskDuration = currentTask.getDuration();
//
//                try {
//                    while (taskDuration <= Duration.between(startTime, Instant.now()).toMillisPart()) {
//                        Thread.sleep(1);
//                        int deltaTime2 = Duration.between(startTime, Instant.now()).toMillisPart();
//                    }
//
//                } catch (InterruptedException e) {
//                    throw new RuntimeException(e);
//                }
//            }

//            if (currentTask != null) {
//                try {
//                    Thread.sleep(currentTask.getDuration());
//                    currentTask.finish();
//                    currentTask = null;
//                } catch (InterruptedException e) {
//                    Thread.currentThread().interrupt();
//                }
//            }


    public void updateRunningTasks(int second) {
        LinkedList<Task> tasksAtSecond = addedTasks.get((long) second);

        if (tasksAtSecond != null) {
            for (Task task : tasksAtSecond) {
                if (runningTasks.isEmpty()) {
                    runningTasks.add(task);
                } else if (runningTasks.getFirst().isPreemptible()) {
                    if (task.getPriority() > runningTasks.getFirst().getPriority()) {
                        runningTasks.addFirst(task);
                    } else {
                        addTaskInOrder(task);
                    }
                } else {
                    addTaskInOrder(task);
                }
            }
        }
    }

    public void addTaskInOrder(Task newTask) {
        boolean added = false;
        for (int i = 1; i < runningTasks.size(); i++) {
            if (newTask.getPriority() > runningTasks.get(i).getPriority()) {
                runningTasks.add(i, newTask);
                added = true;
                break;
            }
        }

        if (!added) {
            runningTasks.addLast(newTask);
        }
    }




    @Override
    public void addTask(Task task) {

        taskAdded = true;
        totalTasks++;

        long key = task.getStart();
        if(addedTasks.get(key) == null){
            LinkedList<Task> auxList = new LinkedList<>();
            auxList.add(task);
            addedTasks.put(key, auxList);
        } else {
            LinkedList<Task> auxList = addedTasks.get(key);
            auxList.add(task);
        }
    }

    @Override
    public int getQueueSize() {
//        int result = 0;
//        for (Map.Entry<Long,  LinkedList<Task>> e : addedTasks.entrySet()) {
//            result += e.getValue().size();
//        }

        return totalTasks - finishedTasks;
    }

    @Override
    public long getWorkLeft() {
        int result = 0;
        for (Map.Entry<Long,  LinkedList<Task>> e : addedTasks.entrySet()) {
            for(Task auxTask : e.getValue()) {
                result += auxTask.getLeft();
            }
        }

        return result;
    }

    @Override
    public void shutdown() {
        isItrunning = false;
        interrupt();
    }
}
