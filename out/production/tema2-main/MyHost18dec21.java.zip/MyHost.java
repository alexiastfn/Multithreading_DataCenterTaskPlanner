/* Implement this class. */

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class MyHost extends Host {

    private Queue<Task> taskQueue = new ConcurrentLinkedQueue<>();
    private boolean isItrunning = true;
    private Task currentTask = null;


    @Override
    public void run() {

        while (isItrunning) {

            Task task = taskQueue.poll();
            if (task != null) {
                try {
                    currentTask = task;
                    Thread.sleep(task.getDuration());
                    task.finish();
                    currentTask = null;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }

    }

    @Override
    public void addTask(Task task) {
        taskQueue.add(task);
        if (currentTask == null || task.getPriority() > currentTask.getPriority()) {
            interrupt();
        }
    }

    @Override
    public int getQueueSize() {
        return taskQueue.size();
    }

    @Override
    public long getWorkLeft() {
        return 0;
    }

    @Override
    public void shutdown() {
        isItrunning = false;
        interrupt();
    }
}
